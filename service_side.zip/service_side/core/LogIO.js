/**
 * Created by shin on 2017/12/11.
 */
class Log{

}